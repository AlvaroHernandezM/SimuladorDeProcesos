package logic;

/**
 *
 * Los cinco estado que puede tener un proceso
 *
 * @author - SO2017
 */
public enum Estado {

    NUEVO, LISTO, EJECUCION, BLOQUEADO, TERMINADO;
}
