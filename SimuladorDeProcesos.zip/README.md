# SimuladorDeProcesos1
Simulador de procesos con ejecución FIFO y cinco estados - Sistemas operativos 2017

Para la correcta visualizacion del LOG del proyecto, ejecutar desde consolo con el comando java -c ejecutable.jar

Encontramos en este repositorio:
	-Código fuente 
	-Documentación: Manual de usuario e informe.
	-Ejecutable JAR
	-Javadoc con toda la documentación interna